import { Link } from 'react-router-dom';
import { useEffect, useState, useRef } from 'react';

export default function EasterEggPage() {
  const [keySequence, setKeySequence] = useState('');
  const [showModal, setShowModal] = useState(false);
  const modalRef = useRef(null);
  const secretCode = '1337';
  const [imageSrc, setImageSrc] = useState('/images/profile-pic.jpg');

  useEffect(() => {
    const handleKeyDown = (event) => {
      const updated = (keySequence + event.key).slice(-secretCode.length);
      setKeySequence(updated);
      if (updated === secretCode) {
        setShowModal(true);
        setKeySequence('');
      }
    };

    const handleWindowClick = (event) => {
      if (modalRef.current && event.target === modalRef.current) {
        setShowModal(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('click', handleWindowClick);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('click', handleWindowClick);
    };
  }, [keySequence]);

  const toggleImage = () => {
    setImageSrc((src) =>
      src.includes('My-alter-ego') ? '/images/profile-pic.jpg' : '/images/My-alter-ego.jpg'
    );
  };

  return (
    <>
      <h1>About Page With Easter Egg</h1>
      <div className="profile_img">
        <img
          id="easterEgg"
          src={imageSrc}
          alt="Easter Egg"
          onClick={toggleImage}
        />
      </div>

      {showModal && (
        <div className="modal" ref={modalRef} style={{ display: 'block' }}>
          <div className="modal-content">
            <span className="close" onClick={() => setShowModal(false)}>×</span>
            <h2>Rudeus Greyrat</h2>
          </div>
        </div>
      )}
    </>
  );
}
