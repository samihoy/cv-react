import { Link } from 'react-router-dom';

export default function CVPage() {
 return (
    <>
      <header className="top">
        <div className="nav">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link className="active" to="/cv">CV</Link></li>
          <li><Link to="/project">Project</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </div>

        <img src="" alt="" />
        <div className="profile">
          <a className="downloadbtn" href="/Made upp Resume.pdf">Resume Download</a>
        </div>
        <h1>Ressume</h1>

        <section className="resume-content">
          <h2>Max Backendson</h2>
          <p>Age: 36 | Email: max.backendson@example.com | Phone: +46 70 123 4567</p>

          <h3>Professional Summary</h3>
          <p>Motivated and versatile professional with over a decade of experience...</p>

          <h3>Work Experience</h3>
          <ul>
            <li><strong>Senior Security Analyst</strong> | NordGuard Security AB | 2009–2023</li>
            <li><strong>Retail Associate</strong> | CityMart | 2015–2019</li>
            <li><strong>Consultant</strong> | Strategic Ops | Ongoing</li>
          </ul>

          <h3>Education</h3>
          <p>BSc in Business and Security Management | University of Stockholm | 2005–2008</p>

          <h3>Key Skills</h3>
          <ul>
            <li>Security Operations</li>
            <li>Team Leadership</li>
            <li>Retail & Inventory Management</li>
          </ul>
        </section>
      </header>

      <div>Aditional information</div>
    </>
  );
}