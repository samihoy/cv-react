import { Link } from 'react-router-dom';

export default function ProjectsPage() {
   return (
    <>
      <header className="top">
        <div className="nav">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/cv">CV</Link></li>
          <li><Link className="active" to="/project">Project</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </div>
      </header>

      <div className="project_img">
        <div className="projekt1">
          <img alt="" className="githubimage" src="/images/Github-desktop-logo-symbol.svg.png" />
          <a className="card" href="#project-card1">github repository</a>
          <div className="cardmodal" id="project-card1">
            <div className="modalcontent">
              <h2>School notes</h2>
              <p>some school notes</p>
              <a className="container" href="https://github.com/samihoy/Lektion-4-API-och-Backend-Aldors-Exempel">Link to Github repo</a>
              <a className="close" href="#">close</a>
            </div>
          </div>
        </div>

        <div className="projekt2">
          <img alt="" className="githubimage" src="/images/Github-desktop-logo-symbol.svg.png" />
          <a className="card" href="#project-card2">github repository</a>
          <div className="cardmodal" id="project-card2">
            <div className="modalcontent">
              <h2>Wealth Specialists</h2>
              <p>School project of a bank application we made, it is very basic and so-so to be honest</p>
              <a className="container" href="https://github.com/samihoy/WealthSpecialists">Link to Github repo</a>
              <a className="close" href="#">close</a>
            </div>
          </div>
        </div>
      </div>

      <div className="card"></div>
    </>
  );
}